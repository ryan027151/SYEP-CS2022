import time
from datetime import datetime, time as ti
import random
from plyer import notification
import tkinter as tk
from tkinter import *

messages = [
    "Give yourself a bo'oh'o'wa'er.", 
    "Say 'Nein!' to Computer and say 'Ja!' to Water.", 
    "Water is the only drink for a wise man.", 
    "Drink more, thirst less.", 
    "Refill, Refresh, Repeat.", 
    "You are a walking tree with different emotions, so get some water when you get some sun.", 
    "Stay hydrated and conquer the day!","Drink up, quench your thirst and feel refreshed!",
    "Water: Nature's elixir for a healthy life.",
    "H2O: The secret to glowing skin and a happy soul.",
    "Don't forget to hydrate and unleash your potential!",
    "Water is the fuel that keeps your body running smoothly.",
    "Sip, sip, hooray! Hydrate your way to greatness.",
    "Water: Your body's best friend. Drink it like you mean it!",
    "Stay cool, stay hydrated, and own every moment.",
    "Hydration is the key to unlocking your full potential.",
    "Water is life's ultimate pick-me-up. Take a sip and feel alive!",
    "Drinking water is like giving your body a big, refreshing hug.",
    "Keep calm and drink water. It's the ultimate stress buster.",
    "Water: The magic potion for a healthy mind and body.",
    "Remember, water is the source of all good vibes. Stay hydrated!",
    "You're unstoppable when you stay hydrated. Keep those sips coming!",
    "Every sip of water is a step towards a healthier, happier you.",
    "Water is the ultimate hero that saves you from fatigue. Stay hydrated!",
    "Hydration is the secret weapon of champions. Drink up and conquer!",
    "Water, the silent superhero that keeps you going strong. Cheers!"
]

time_range = {
    'morning': [ti(hour=8, minute=0, second=0), ti(hour=10, minute=30, second=0)],
    'afternoon': [ti(hour=11, minute=30, second=0), ti(hour=15, minute=0, second=0)],
    'night': [ti(hour=17, minute=0, second=1), ti(hour=19, minute=59, second=59)]
}

water_amount = 0
on = True

while on:
   if __name__=='__main__':
      keep_on = input()
      #pop-up window to ask user question

      root = tk.Tk() # create the main window
      root.title("Water Reminder")
      root.resizable(0,0)
      root.configure(bg="#b8a7aa")

      #questions
      question_list = ["Is your color of urine this morning yellow or not?",
                       "Did you losing water through sweat because you're exercising in last 12 hours?",
                       "Does the outside temperature feel warm for you today?",
                       "Do you feel any weakness, low blood pressure, dizziness, tiredness, or confusion due to lack of water?",
                       "Is your skin currently at a bad health, unclean stage?",
                       ""]
     
      #create questions
      question = question_list[0]
      text = tk.Label(root,text=question,font=("Arial",10,"bold"), wraplength= 250, width=50)
      
      #button functions
      def yes_button_clicked():
         global water_amount
         global question_list
         question_list.remove(question_list[0])
         water_amount += 50
         text.config(text = question_list[0])
         if question_list[0] == "":
            root.destroy()
      
      def no_button_clicked():
         global question_list
         question_list.remove(question_list[0])
         text.config(text = question_list[0])
         if question_list[0] =="":
            root.destroy()
   
      #create the buttons
      yes_button = tk.Button(root,text="Yes",command=yes_button_clicked,bg="#48373d",fg="#7f6e72")
      no_button = tk.Button(root,text="No",command=no_button_clicked,bg="#48373d",fg="#7f6e72")

      #text in the pop up window
      text.grid(row=1,column = 2,columnspan = 2)

      #buttons in the pop up window
      yes_button.grid(row=2,column=1,pady=60,padx = 100,columnspan = 2)
      no_button.grid(row=2,column=3,pady=60,columnspan=2,padx=100)

      root.mainloop() #start the main event loop

      now = datetime.now()
      current_time = ti(hour=now.hour, minute=now.minute, second=now.second)
      current_time_str = now.strftime("%H:%M:%S")

      # Comparison
      if current_time <= time_range['morning'][1] and current_time >= time_range['morning'][0]:
         water_amount += 270
      elif current_time <= time_range['afternoon'][1] and current_time >= time_range['afternoon'][0]:
         water_amount += 300
      elif current_time <= time_range['night'][1] and current_time >= time_range['night'][0]:
         water_amount += 300
      else:
         water_amount = 'any amount of wanted'

      notification.notify(
         title=f'Water Reminder: Drink {water_amount}mL of water',
         message=random.choice(messages),
         app_icon='glass.ico',
         timeout=30
      )

      if current_time_str >= '20:00:00':
         notification.notify(
               title='Bye!',
               message="No water is needed at this moment.",
               app_icon='glass.ico',
               timeout=30
         )
         on = False

      time.sleep(60 * 90) #1.5 hr timeout after each notification